"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lib/prisma.ts
var import_client, import_adapter_pg, globalForPrisma, connectionString, adapter, prisma;
var init_prisma = __esm({
  "src/lib/prisma.ts"() {
    "use strict";
    import_client = require("@prisma/client");
    import_adapter_pg = require("@prisma/adapter-pg");
    globalForPrisma = global;
    connectionString = process.env.DATABASE_URL;
    if (!connectionString) {
      throw new Error("DATABASE_URL is required");
    }
    adapter = new import_adapter_pg.PrismaPg({ connectionString });
    prisma = globalForPrisma.prisma || new import_client.PrismaClient({ adapter });
    if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
  }
});

// src/lib/auth.ts
var import_jsonwebtoken, JWT_SECRET, requireAuth;
var init_auth = __esm({
  "src/lib/auth.ts"() {
    "use strict";
    import_jsonwebtoken = __toESM(require("jsonwebtoken"));
    JWT_SECRET = process.env.JWT_SECRET || "super-secret-key-for-development-only";
    requireAuth = async (req, res, next) => {
      const authHeader = req.headers.authorization;
      const bearerToken = authHeader?.startsWith("Bearer ") ? authHeader.slice(7) : void 0;
      const token = req.cookies?.token || bearerToken;
      if (!token) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      try {
        const payload = import_jsonwebtoken.default.verify(token, JWT_SECRET);
        if (!payload.userId) {
          throw new Error("Invalid token payload");
        }
        req.userId = payload.userId;
        next();
      } catch (error) {
        return res.status(401).json({ error: "Invalid or expired token" });
      }
    };
  }
});

// src/routes/auth.ts
var import_express, import_bcryptjs, import_jsonwebtoken2, router, JWT_SECRET2, FRONTEND_URL, BACKEND_URL, isProduction, authCookieOptions, auth_default;
var init_auth2 = __esm({
  "src/routes/auth.ts"() {
    "use strict";
    import_express = require("express");
    import_bcryptjs = __toESM(require("bcryptjs"));
    import_jsonwebtoken2 = __toESM(require("jsonwebtoken"));
    init_prisma();
    init_auth();
    router = (0, import_express.Router)();
    JWT_SECRET2 = process.env.JWT_SECRET || "super-secret-key-for-development-only";
    FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:3000";
    BACKEND_URL = process.env.BACKEND_URL || "http://localhost:5000";
    isProduction = () => process.env.NODE_ENV === "production";
    authCookieOptions = () => ({
      httpOnly: true,
      secure: isProduction(),
      sameSite: isProduction() ? "none" : "lax",
      path: "/",
      maxAge: 7 * 24 * 60 * 60 * 1e3
    });
    router.post("/signup", async (req, res) => {
      try {
        const { name, email, password } = req.body;
        if (!name || !email || !password) {
          return res.status(400).json({ error: "Missing fields" });
        }
        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
          return res.status(400).json({ error: "User already exists" });
        }
        const hashedPassword = await import_bcryptjs.default.hash(password, 10);
        const user = await prisma.user.create({
          data: { name, email, password: hashedPassword, fiatBalance: 0 }
        });
        const token = import_jsonwebtoken2.default.sign({ userId: user.id }, JWT_SECRET2, { expiresIn: "7d" });
        res.cookie("token", token, authCookieOptions());
        return res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router.post("/login", async (req, res) => {
      try {
        const { email, password } = req.body;
        if (!email || !password) {
          return res.status(400).json({ error: "Missing fields" });
        }
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user || !user.password) {
          return res.status(401).json({ error: "Invalid credentials" });
        }
        const valid = await import_bcryptjs.default.compare(password, user.password);
        if (!valid) {
          return res.status(401).json({ error: "Invalid credentials" });
        }
        const token = import_jsonwebtoken2.default.sign({ userId: user.id }, JWT_SECRET2, { expiresIn: "7d" });
        res.cookie("token", token, authCookieOptions());
        return res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router.post("/logout", (req, res) => {
      res.cookie("token", "", { ...authCookieOptions(), maxAge: -1 });
      return res.json({ success: true });
    });
    router.get("/me", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        if (!userId) {
          return res.status(401).json({ authenticated: false });
        }
        const user = await prisma.user.findUnique({ where: { id: userId } });
        if (!user) {
          return res.status(404).json({ error: "User not found", authenticated: false });
        }
        return res.json({ authenticated: true, user: { id: user.id, name: user.name, email: user.email } });
      } catch (error) {
        return res.status(500).json({ authenticated: false });
      }
    });
    router.get("/google", (req, res) => {
      const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
      const redirectUri = `${BACKEND_URL}/api/auth/google/callback`;
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${GOOGLE_CLIENT_ID}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=email%20profile`;
      res.redirect(authUrl);
    });
    router.get("/google/callback", async (req, res) => {
      const code = req.query.code;
      if (!code) {
        return res.redirect(`${FRONTEND_URL}?error=NoCode`);
      }
      const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
      const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
      const redirectUri = `${BACKEND_URL}/api/auth/google/callback`;
      try {
        const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            code,
            client_id: GOOGLE_CLIENT_ID,
            client_secret: GOOGLE_CLIENT_SECRET,
            redirect_uri: redirectUri,
            grant_type: "authorization_code"
          })
        });
        const tokenData = await tokenResponse.json();
        if (tokenData.error) throw new Error(tokenData.error);
        const userResponse = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
          headers: { Authorization: `Bearer ${tokenData.access_token}` }
        });
        const userData = await userResponse.json();
        let user = await prisma.user.findUnique({ where: { email: userData.email } });
        if (!user) {
          user = await prisma.user.create({
            data: {
              email: userData.email,
              name: userData.name,
              fiatBalance: 1e4
            }
          });
        }
        const token = import_jsonwebtoken2.default.sign({ userId: user.id }, JWT_SECRET2, { expiresIn: "7d" });
        res.cookie("token", token, authCookieOptions());
        const redirectUrl = new URL(FRONTEND_URL);
        redirectUrl.searchParams.set("token", token);
        return res.redirect(redirectUrl.toString());
      } catch (error) {
        console.error("Google Auth Error:", error);
        return res.redirect(`${FRONTEND_URL}?error=GoogleAuthFailed`);
      }
    });
    auth_default = router;
  }
});

// src/routes/portfolio.ts
var import_express2, router2, portfolio_default;
var init_portfolio = __esm({
  "src/routes/portfolio.ts"() {
    "use strict";
    import_express2 = require("express");
    init_prisma();
    init_auth();
    router2 = (0, import_express2.Router)();
    router2.get("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const user = await prisma.user.findUnique({
          where: { id: userId },
          include: {
            portfolios: {
              include: {
                asset: true
              }
            }
          }
        });
        if (!user) {
          return res.status(404).json({ error: "User not found" });
        }
        return res.json({
          fiatBalance: user.fiatBalance,
          lockedFiatBalance: user.lockedFiatBalance,
          holdings: user.portfolios.map((p) => ({
            id: p.id,
            symbol: p.asset.symbol,
            name: p.asset.name,
            type: p.asset.type,
            quantity: p.quantity,
            lockedQuantity: p.lockedQuantity,
            averagePurchasePrice: p.averagePurchasePrice
          }))
        });
      } catch (error) {
        console.error("Portfolio GET Error:", error);
        return res.status(500).json({ error: "Internal Server Error" });
      }
    });
    portfolio_default = router2;
  }
});

// src/routes/prices.ts
var import_express3, import_yahoo_finance2, router3, YahooFinance, yahooFinance, CRYPTO_SYMBOLS, toYahooSymbol, prices_default;
var init_prices = __esm({
  "src/routes/prices.ts"() {
    "use strict";
    import_express3 = require("express");
    import_yahoo_finance2 = __toESM(require("yahoo-finance2"));
    router3 = (0, import_express3.Router)();
    YahooFinance = import_yahoo_finance2.default.default || import_yahoo_finance2.default;
    yahooFinance = new YahooFinance({ suppressNotices: ["yahooSurvey", "ripHistorical"] });
    CRYPTO_SYMBOLS = /* @__PURE__ */ new Set(["BTC", "ETH", "SOL", "DOGE", "ADA"]);
    toYahooSymbol = (symbol) => {
      const cleanSymbol = symbol.trim().toUpperCase();
      return CRYPTO_SYMBOLS.has(cleanSymbol) ? `${cleanSymbol}-USD` : cleanSymbol;
    };
    router3.get("/", async (req, res) => {
      try {
        const symbolsParam = req.query.symbols;
        if (!symbolsParam) {
          return res.status(400).json({ error: "Symbols parameter is required" });
        }
        const symbols = symbolsParam.split(",").map((symbol) => symbol.trim().toUpperCase()).filter(Boolean);
        const quotes = await Promise.all(
          symbols.map(async (symbol) => {
            try {
              const result = await yahooFinance.quote(toYahooSymbol(symbol));
              return {
                symbol,
                price: result.regularMarketPrice,
                change: result.regularMarketChange,
                changePercent: result.regularMarketChangePercent,
                name: result.shortName || result.longName || symbol
              };
            } catch (e) {
              console.error(`Failed to fetch quote for ${symbol}:`, e);
              return null;
            }
          })
        );
        const validQuotes = quotes.filter(Boolean);
        const priceMap = validQuotes.reduce((acc, quote) => {
          if (typeof quote.price === "number") {
            acc[quote.symbol] = quote.price;
          }
          return acc;
        }, {});
        return res.json({ prices: priceMap });
      } catch (error) {
        console.error("Prices GET Error:", error);
        return res.status(500).json({ error: "Internal Server Error" });
      }
    });
    router3.get("/history", async (req, res) => {
      try {
        const symbol = req.query.symbol;
        const range = req.query.range || "1mo";
        if (!symbol) {
          return res.status(400).json({ error: "Symbol parameter is required" });
        }
        const now = /* @__PURE__ */ new Date();
        let period1 = /* @__PURE__ */ new Date();
        let interval = "1d";
        switch (range) {
          case "1d":
            period1.setDate(now.getDate() - 1);
            interval = "15m";
            break;
          case "5d":
            period1.setDate(now.getDate() - 5);
            interval = "15m";
            break;
          case "1mo":
            period1.setMonth(now.getMonth() - 1);
            interval = "1d";
            break;
          case "3mo":
            period1.setMonth(now.getMonth() - 3);
            interval = "1d";
            break;
          case "1y":
            period1.setFullYear(now.getFullYear() - 1);
            interval = "1wk";
            break;
          default:
            period1.setMonth(now.getMonth() - 1);
            interval = "1d";
        }
        const result = await yahooFinance.chart(toYahooSymbol(symbol), {
          period1,
          period2: now,
          interval
        });
        const formattedData = (result.quotes || []).map((item) => ({
          date: item.date,
          price: item.close
        })).filter((item) => item.date && typeof item.price === "number");
        return res.json({ history: formattedData });
      } catch (error) {
        console.error("Prices History Error:", error);
        return res.status(500).json({ error: "Failed to fetch history" });
      }
    });
    prices_default = router3;
  }
});

// src/routes/trade.ts
var import_express4, router4, trade_default;
var init_trade = __esm({
  "src/routes/trade.ts"() {
    "use strict";
    import_express4 = require("express");
    init_prisma();
    init_auth();
    router4 = (0, import_express4.Router)();
    router4.post("/buy", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const { symbol, quantity, currentPrice } = req.body;
        if (!symbol || !quantity || !currentPrice || quantity <= 0) {
          return res.status(400).json({ error: "Missing or invalid fields" });
        }
        const totalCost = quantity * currentPrice;
        let asset = await prisma.asset.findUnique({ where: { symbol } });
        if (!asset) {
          asset = await prisma.asset.create({
            data: { symbol, name: symbol, type: "CRYPTO" }
            // defaulting to CRYPTO for unknown
          });
        }
        const result = await prisma.$transaction(async (tx) => {
          const user = await tx.user.findUnique({ where: { id: userId } });
          if (!user) throw new Error("User not found");
          if (user.fiatBalance < totalCost) {
            throw new Error("Insufficient fiat balance");
          }
          await tx.user.update({
            where: { id: userId },
            data: { fiatBalance: { decrement: totalCost } }
          });
          const portfolio = await tx.portfolio.findUnique({
            where: { userId_assetId: { userId, assetId: asset.id } }
          });
          if (portfolio) {
            const currentTotalCost = portfolio.quantity * portfolio.averagePurchasePrice;
            const newTotalCost = currentTotalCost + totalCost;
            const newQuantity = portfolio.quantity + quantity;
            const newAveragePrice = newTotalCost / newQuantity;
            await tx.portfolio.update({
              where: { id: portfolio.id },
              data: {
                quantity: newQuantity,
                averagePurchasePrice: newAveragePrice
              }
            });
          } else {
            await tx.portfolio.create({
              data: {
                userId,
                assetId: asset.id,
                quantity,
                averagePurchasePrice: currentPrice
              }
            });
          }
          await tx.transaction.create({
            data: {
              userId,
              assetId: asset.id,
              type: "BUY",
              quantity,
              pricePerUnit: currentPrice,
              totalValue: totalCost
            }
          });
          return { success: true };
        });
        return res.json(result);
      } catch (error) {
        return res.status(400).json({ error: error.message || "Trade failed" });
      }
    });
    router4.post("/sell", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const { symbol, quantity, currentPrice } = req.body;
        if (!symbol || !quantity || !currentPrice || quantity <= 0) {
          return res.status(400).json({ error: "Missing or invalid fields" });
        }
        const totalReturn = quantity * currentPrice;
        const result = await prisma.$transaction(async (tx) => {
          const asset = await tx.asset.findUnique({ where: { symbol } });
          if (!asset) throw new Error("Asset not found in portfolio");
          const portfolio = await tx.portfolio.findUnique({
            where: { userId_assetId: { userId, assetId: asset.id } }
          });
          if (!portfolio || portfolio.quantity < quantity) {
            throw new Error("Insufficient asset quantity");
          }
          await tx.portfolio.update({
            where: { id: portfolio.id },
            data: {
              quantity: { decrement: quantity }
            }
          });
          await tx.user.update({
            where: { id: userId },
            data: { fiatBalance: { increment: totalReturn } }
          });
          await tx.transaction.create({
            data: {
              userId,
              assetId: asset.id,
              type: "SELL",
              quantity,
              pricePerUnit: currentPrice,
              totalValue: totalReturn
            }
          });
          return { success: true };
        });
        return res.json(result);
      } catch (error) {
        return res.status(400).json({ error: error.message || "Trade failed" });
      }
    });
    trade_default = router4;
  }
});

// src/routes/wallet.ts
var import_express5, router5, wallet_default;
var init_wallet = __esm({
  "src/routes/wallet.ts"() {
    "use strict";
    import_express5 = require("express");
    init_prisma();
    init_auth();
    router5 = (0, import_express5.Router)();
    router5.post("/", requireAuth, async (req, res) => {
      try {
        const { action, amount } = req.body;
        if (!action || !amount || amount <= 0) {
          return res.status(400).json({ error: "Invalid action or amount" });
        }
        const userId = req.userId;
        const result = await prisma.$transaction(async (tx) => {
          const user = await tx.user.findUnique({ where: { id: userId } });
          if (!user) {
            throw new Error("User not found");
          }
          if (action === "withdraw" && user.fiatBalance < amount) {
            throw new Error("Insufficient funds");
          }
          const updatedUser = await tx.user.update({
            where: { id: userId },
            data: {
              fiatBalance: action === "deposit" ? { increment: amount } : { decrement: amount }
            }
          });
          const transaction = await tx.transaction.create({
            data: {
              userId,
              type: action === "deposit" ? "DEPOSIT" : "WITHDRAW",
              quantity: 0,
              pricePerUnit: 1,
              totalValue: amount
            }
          });
          return { balance: updatedUser.fiatBalance, transaction };
        });
        return res.json(result);
      } catch (error) {
        console.error("Wallet Action Error:", error);
        return res.status(500).json({ error: error.message || "Internal Server Error" });
      }
    });
    wallet_default = router5;
  }
});

// src/routes/watchlist.ts
var import_express6, router6, watchlist_default;
var init_watchlist = __esm({
  "src/routes/watchlist.ts"() {
    "use strict";
    import_express6 = require("express");
    init_prisma();
    init_auth();
    router6 = (0, import_express6.Router)();
    router6.get("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const user = await prisma.user.findUnique({
          where: { id: userId },
          include: {
            watchlists: true
          }
        });
        if (!user) {
          return res.status(404).json({ error: "User not found" });
        }
        return res.json({ watchlists: user.watchlists });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router6.post("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const { symbol } = req.body;
        if (!symbol) {
          return res.status(400).json({ error: "Symbol is required" });
        }
        const watchlist = await prisma.watchlist.create({
          data: {
            userId,
            symbol
          }
        });
        return res.json({ watchlist });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router6.delete("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const symbol = req.query.symbol;
        if (!symbol) {
          return res.status(400).json({ error: "Symbol is required" });
        }
        await prisma.watchlist.deleteMany({
          where: {
            userId,
            symbol
          }
        });
        return res.json({ success: true });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    watchlist_default = router6;
  }
});

// src/routes/alerts.ts
var import_express7, router7, alerts_default;
var init_alerts = __esm({
  "src/routes/alerts.ts"() {
    "use strict";
    import_express7 = require("express");
    init_prisma();
    init_auth();
    router7 = (0, import_express7.Router)();
    router7.get("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const alerts = await prisma.alert.findMany({
          where: { userId },
          orderBy: { createdAt: "desc" }
        });
        return res.json({ alerts });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router7.post("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const { symbol, targetPrice, condition } = req.body;
        if (!symbol || !targetPrice || !condition) {
          return res.status(400).json({ error: "Missing required fields" });
        }
        const alert = await prisma.alert.create({
          data: {
            userId,
            symbol,
            targetPrice,
            direction: condition
          }
        });
        return res.json({ alert });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router7.delete("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const id = req.query.alertId || req.query.id;
        if (!id) {
          return res.status(400).json({ error: "Alert ID is required" });
        }
        await prisma.alert.deleteMany({
          where: {
            id,
            userId
          }
        });
        return res.json({ success: true });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    alerts_default = router7;
  }
});

// src/lib/matchingEngine.ts
async function processOrder(orderId) {
  await prisma.$transaction(async (tx) => {
    const order = await tx.order.findUnique({
      where: { id: orderId },
      include: { asset: true, user: true }
    });
    if (!order) return;
    if (order.status !== "PENDING" && order.status !== "PARTIAL") return;
    if (order.orderType !== "LIMIT" || !order.price) return;
    let remainingQuantity = order.quantity - order.filledQuantity;
    if (remainingQuantity <= 0) return;
    let matchingOrders = [];
    if (order.type === "BUY") {
      matchingOrders = await tx.order.findMany({
        where: {
          assetId: order.assetId,
          type: "SELL",
          status: { in: ["PENDING", "PARTIAL"] },
          price: { lte: order.price }
          // Seller wants less than or equal to what buyer is willing to pay
        },
        orderBy: [
          { price: "asc" },
          // Best price first
          { createdAt: "asc" }
          // Oldest first
        ]
      });
    } else if (order.type === "SELL") {
      matchingOrders = await tx.order.findMany({
        where: {
          assetId: order.assetId,
          type: "BUY",
          status: { in: ["PENDING", "PARTIAL"] },
          price: { gte: order.price }
          // Buyer is willing to pay more than or equal to what seller wants
        },
        orderBy: [
          { price: "desc" },
          // Best price first
          { createdAt: "asc" }
          // Oldest first
        ]
      });
    }
    for (const match of matchingOrders) {
      if (remainingQuantity <= 0) break;
      if (!match.price) continue;
      const matchRemaining = match.quantity - match.filledQuantity;
      const fillQuantity = Math.min(remainingQuantity, matchRemaining);
      const executionPrice = match.price;
      const totalValue = fillQuantity * executionPrice;
      const newMatchFilled = match.filledQuantity + fillQuantity;
      const matchStatus = Math.abs(newMatchFilled - match.quantity) < 1e-6 ? "FILLED" : "PARTIAL";
      await tx.order.update({
        where: { id: match.id },
        data: { filledQuantity: newMatchFilled, status: matchStatus }
      });
      const newOrderFilled = order.filledQuantity + fillQuantity;
      remainingQuantity -= fillQuantity;
      const orderStatus = Math.abs(newOrderFilled - order.quantity) < 1e-6 ? "FILLED" : "PARTIAL";
      await tx.order.update({
        where: { id: order.id },
        data: { filledQuantity: newOrderFilled, status: orderStatus }
      });
      const buyerId = order.type === "BUY" ? order.userId : match.userId;
      const sellerId = order.type === "SELL" ? order.userId : match.userId;
      const buyPriceLimit = order.type === "BUY" ? order.price : match.price;
      await tx.portfolio.updateMany({
        where: { userId: sellerId, assetId: order.assetId },
        data: {
          lockedQuantity: { decrement: fillQuantity },
          quantity: { decrement: fillQuantity }
        }
      });
      await tx.user.update({
        where: { id: sellerId },
        data: {
          fiatBalance: { increment: totalValue }
        }
      });
      const lockedFiatAmount = fillQuantity * buyPriceLimit;
      const refundAmount = lockedFiatAmount - totalValue;
      await tx.user.update({
        where: { id: buyerId },
        data: {
          lockedFiatBalance: { decrement: lockedFiatAmount },
          fiatBalance: { increment: refundAmount }
          // Refund if matched at better price
        }
      });
      let buyerPortfolio = await tx.portfolio.findUnique({
        where: { userId_assetId: { userId: buyerId, assetId: order.assetId } }
      });
      if (buyerPortfolio) {
        const existingQty = buyerPortfolio.quantity;
        const existingCost = existingQty * buyerPortfolio.averagePurchasePrice;
        const newAvg = (existingCost + totalValue) / (existingQty + fillQuantity);
        await tx.portfolio.update({
          where: { id: buyerPortfolio.id },
          data: {
            quantity: { increment: fillQuantity },
            averagePurchasePrice: newAvg
          }
        });
      } else {
        await tx.portfolio.create({
          data: {
            userId: buyerId,
            assetId: order.assetId,
            quantity: fillQuantity,
            averagePurchasePrice: executionPrice
          }
        });
      }
      await tx.transaction.create({
        data: {
          userId: buyerId,
          assetId: order.assetId,
          type: "BUY",
          quantity: fillQuantity,
          pricePerUnit: executionPrice,
          totalValue
        }
      });
      await tx.transaction.create({
        data: {
          userId: sellerId,
          assetId: order.assetId,
          type: "SELL",
          quantity: fillQuantity,
          pricePerUnit: executionPrice,
          totalValue
        }
      });
    }
  });
}
var init_matchingEngine = __esm({
  "src/lib/matchingEngine.ts"() {
    "use strict";
    init_prisma();
  }
});

// src/routes/orders.ts
var import_express8, router8, orders_default;
var init_orders = __esm({
  "src/routes/orders.ts"() {
    "use strict";
    import_express8 = require("express");
    init_prisma();
    init_auth();
    init_matchingEngine();
    router8 = (0, import_express8.Router)();
    router8.get("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const orders = await prisma.order.findMany({
          where: { userId },
          orderBy: { createdAt: "desc" },
          include: { asset: true }
        });
        return res.json({ orders });
      } catch (error) {
        return res.status(401).json({ error: error.message });
      }
    });
    router8.post("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const { symbol, type, orderType, quantity, price } = req.body;
        if (!symbol || !type || !orderType || !quantity || quantity <= 0) {
          return res.status(400).json({ error: "Missing or invalid fields" });
        }
        if (orderType === "LIMIT" && (!price || price <= 0)) {
          return res.status(400).json({ error: "Price required for Limit orders" });
        }
        let asset = await prisma.asset.findUnique({ where: { symbol } });
        if (!asset) {
          asset = await prisma.asset.create({
            data: { symbol, name: symbol, type: "CRYPTO" }
            // default crypto
          });
        }
        const newOrder = await prisma.$transaction(async (tx) => {
          if (type === "BUY") {
            const user = await tx.user.findUnique({ where: { id: userId } });
            const requiredFiat = quantity * price;
            if (!user || user.fiatBalance < requiredFiat) {
              throw new Error("Insufficient fiat balance");
            }
            await tx.user.update({
              where: { id: userId },
              data: {
                fiatBalance: { decrement: requiredFiat },
                lockedFiatBalance: { increment: requiredFiat }
              }
            });
          } else if (type === "SELL") {
            const portfolio = await tx.portfolio.findUnique({
              where: { userId_assetId: { userId, assetId: asset.id } }
            });
            if (!portfolio || portfolio.quantity < quantity) {
              throw new Error("Insufficient asset quantity");
            }
            await tx.portfolio.update({
              where: { id: portfolio.id },
              data: {
                quantity: { decrement: quantity },
                lockedQuantity: { increment: quantity }
              }
            });
          }
          return await tx.order.create({
            data: {
              userId,
              assetId: asset.id,
              type,
              orderType,
              price,
              quantity,
              status: "PENDING"
            }
          });
        });
        processOrder(newOrder.id).catch(console.error);
        return res.json({ order: newOrder });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    router8.delete("/", requireAuth, async (req, res) => {
      try {
        const userId = req.userId;
        const orderId = req.query.orderId;
        if (!orderId) {
          return res.status(400).json({ error: "orderId is required" });
        }
        await prisma.$transaction(async (tx) => {
          const order = await tx.order.findUnique({ where: { id: orderId } });
          if (!order || order.userId !== userId) throw new Error("Order not found");
          if (order.status !== "PENDING" && order.status !== "PARTIAL") throw new Error("Order cannot be cancelled");
          const remainingQty = order.quantity - order.filledQuantity;
          if (order.type === "BUY" && order.price) {
            const refundFiat = remainingQty * order.price;
            await tx.user.update({
              where: { id: userId },
              data: {
                lockedFiatBalance: { decrement: refundFiat },
                fiatBalance: { increment: refundFiat }
              }
            });
          } else if (order.type === "SELL") {
            await tx.portfolio.updateMany({
              where: { userId, assetId: order.assetId },
              data: {
                lockedQuantity: { decrement: remainingQty },
                quantity: { increment: remainingQty }
              }
            });
          }
          await tx.order.update({
            where: { id: orderId },
            data: { status: "CANCELLED" }
          });
        });
        return res.json({ success: true });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    orders_default = router8;
  }
});

// src/routes/orderbook.ts
var import_express9, router9, orderbook_default;
var init_orderbook = __esm({
  "src/routes/orderbook.ts"() {
    "use strict";
    import_express9 = require("express");
    init_prisma();
    router9 = (0, import_express9.Router)();
    router9.get("/", async (req, res) => {
      try {
        const symbol = req.query.symbol;
        if (!symbol) {
          return res.status(400).json({ error: "Symbol is required" });
        }
        const asset = await prisma.asset.findUnique({ where: { symbol } });
        if (!asset) return res.json({ bids: [], asks: [] });
        const rawBids = await prisma.order.findMany({
          where: { assetId: asset.id, type: "BUY", status: { in: ["PENDING", "PARTIAL"] } },
          select: { price: true, quantity: true, filledQuantity: true }
        });
        const rawAsks = await prisma.order.findMany({
          where: { assetId: asset.id, type: "SELL", status: { in: ["PENDING", "PARTIAL"] } },
          select: { price: true, quantity: true, filledQuantity: true }
        });
        const aggregate = (orders) => {
          const map = /* @__PURE__ */ new Map();
          orders.forEach((o) => {
            if (!o.price) return;
            const remaining = o.quantity - o.filledQuantity;
            if (remaining <= 0) return;
            map.set(o.price, (map.get(o.price) || 0) + remaining);
          });
          return Array.from(map.entries()).map(([price, quantity]) => ({ price, quantity }));
        };
        const bids = aggregate(rawBids).sort((a, b) => b.price - a.price);
        const asks = aggregate(rawAsks).sort((a, b) => a.price - b.price);
        return res.json({
          bids: bids.slice(0, 10),
          asks: asks.slice(0, 10)
        });
      } catch (error) {
        return res.status(500).json({ error: error.message });
      }
    });
    orderbook_default = router9;
  }
});

// src/app.ts
var app_exports = {};
__export(app_exports, {
  app: () => app
});
var import_config, import_express10, import_cors, import_cookie_parser, app;
var init_app = __esm({
  "src/app.ts"() {
    "use strict";
    import_config = require("dotenv/config");
    import_express10 = __toESM(require("express"));
    import_cors = __toESM(require("cors"));
    import_cookie_parser = __toESM(require("cookie-parser"));
    init_auth2();
    init_portfolio();
    init_prices();
    init_trade();
    init_wallet();
    init_watchlist();
    init_alerts();
    init_orders();
    init_orderbook();
    app = (0, import_express10.default)();
    app.set("trust proxy", 1);
    app.use((0, import_cors.default)({
      origin: process.env.FRONTEND_URL || "http://localhost:3000",
      credentials: true
    }));
    app.use(import_express10.default.json());
    app.use((0, import_cookie_parser.default)());
    app.use("/api/auth", auth_default);
    app.use("/api/portfolio", portfolio_default);
    app.use("/api/prices", prices_default);
    app.use("/api/trade", trade_default);
    app.use("/api/wallet", wallet_default);
    app.use("/api/watchlist", watchlist_default);
    app.use("/api/alerts", alerts_default);
    app.use("/api/orders", orders_default);
    app.use("/api/orderbook", orderbook_default);
  }
});

// netlify/functions/api.ts
var api_exports = {};
__export(api_exports, {
  config: () => config,
  default: () => api_default
});
module.exports = __toCommonJS(api_exports);
var import_dotenv = __toESM(require("dotenv"));
var import_fs = require("fs");
var import_path = require("path");
var import_serverless_http = __toESM(require("serverless-http"));
var loadEnv = () => {
  const envPaths = [
    (0, import_path.resolve)(process.cwd(), ".env"),
    (0, import_path.resolve)(process.cwd(), "netlify/functions/.env"),
    (0, import_path.resolve)(__dirname, ".env"),
    (0, import_path.resolve)(__dirname, "../../.env")
  ];
  for (const envPath of envPaths) {
    if ((0, import_fs.existsSync)(envPath)) {
      import_dotenv.default.config({ path: envPath });
      return;
    }
  }
};
var handler;
var getHandler = async () => {
  if (!handler) {
    loadEnv();
    const { app: app2 } = await Promise.resolve().then(() => (init_app(), app_exports));
    handler = (0, import_serverless_http.default)(app2);
  }
  return handler;
};
var toEvent = async (req) => {
  const url = new URL(req.url);
  const headers = Object.fromEntries(req.headers.entries());
  const multiValueQueryStringParameters = {};
  url.searchParams.forEach((value, key) => {
    multiValueQueryStringParameters[key] = [
      ...multiValueQueryStringParameters[key] || [],
      value
    ];
  });
  const queryStringParameters = Object.fromEntries(
    Object.entries(multiValueQueryStringParameters).map(([key, values]) => [key, values[0]])
  );
  return {
    rawUrl: req.url,
    rawQuery: url.searchParams.toString(),
    path: url.pathname,
    httpMethod: req.method,
    headers,
    multiValueHeaders: Object.fromEntries(
      Object.entries(headers).map(([key, value]) => [key, value ? [value] : void 0])
    ),
    queryStringParameters,
    multiValueQueryStringParameters,
    body: ["GET", "HEAD"].includes(req.method) ? null : await req.text(),
    isBase64Encoded: false
  };
};
var toResponse = (result) => {
  const headers = new Headers();
  for (const [key, value] of Object.entries(result.headers || {})) {
    headers.set(key, String(value));
  }
  for (const [key, values] of Object.entries(result.multiValueHeaders || {})) {
    for (const value of values) {
      headers.append(key, String(value));
    }
  }
  const body = [204, 304].includes(result.statusCode) ? null : result.isBase64Encoded && result.body ? Buffer.from(result.body, "base64") : result.body;
  return new Response(body, {
    status: result.statusCode,
    headers
  });
};
var api_default = async (req, context) => {
  const handler2 = await getHandler();
  const event = await toEvent(req);
  const result = await handler2(event, context);
  return toResponse(result);
};
var config = {
  path: "/api/*"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
